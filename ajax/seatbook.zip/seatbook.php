<?php 
	include '../admin/config/conn.php';
	$selectedVal = $_POST['selectVal'];
	
	$sqlGet = 'select * from seats where Event_Id=52';
	$getQuery = mysqli_query($conn, $sqlGet);
	
	if($getQuery->num_rows == 0){
		$sqlAdd = "insert into seats (Id, Event_Id, BookSeat, Status, CreatedDate) values ('', 52, '".$selectedVal."', 1, '')";
		$addQuery = mysqli_query($conn, $sqlAdd);
	} else {
		$data = mysqli_fetch_assoc($getQuery);
		$getArr = $data['BookSeat'];
		$maval = $getArr.$selectedVal;
		echo $maval;
		$upSql = "update seats set BookSeat='".$maval."' Where Event_Id=52";
		$updQuery = mysqli_query($conn, $upSql);
	}
?>